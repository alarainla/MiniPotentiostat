﻿namespace ControlApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.l_FREQ = new System.Windows.Forms.Label();
            this.l_AMP = new System.Windows.Forms.Label();
            this.l_STEP = new System.Windows.Forms.Label();
            this.l_SR = new System.Windows.Forms.Label();
            this.b_Stop = new System.Windows.Forms.Button();
            this.l_Xlabel = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.l_Xmin = new System.Windows.Forms.Label();
            this.l_Xmax = new System.Windows.Forms.Label();
            this.l_Ymin = new System.Windows.Forms.Label();
            this.l_Ymax = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.tb_CVNScans = new System.Windows.Forms.TextBox();
            this.b_Save = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.tb_SWVFreq = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tb_SWVAmp = new System.Windows.Forms.TextBox();
            this.b_SWV = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.tb_SWVStep = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tb_SWVStop = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tb_SWVStart = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tb_CVRate = new System.Windows.Forms.TextBox();
            this.b_CV = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.tb_CVSecond = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tb_CVFirst = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tb_CVStartStop = new System.Windows.Forms.TextBox();
            this.b_CA = new System.Windows.Forms.Button();
            this.b_Set = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.tb_CATimeStep = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_CATime = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.l_running = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_CAPot = new System.Windows.Forms.TextBox();
            this.tb_Pot = new System.Windows.Forms.TextBox();
            this.l_connection = new System.Windows.Forms.Label();
            this.l_status = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.l_CalibForm = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_ICalibB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_ICalibA = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_VCalibB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_VCalibA = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_COMPorts = new System.Windows.Forms.ComboBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.sp_Device = new System.IO.Ports.SerialPort(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label26 = new System.Windows.Forms.Label();
            this.pb_Graph = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Graph)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(922, 639);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.l_FREQ);
            this.tabPage1.Controls.Add(this.l_AMP);
            this.tabPage1.Controls.Add(this.l_STEP);
            this.tabPage1.Controls.Add(this.l_SR);
            this.tabPage1.Controls.Add(this.b_Stop);
            this.tabPage1.Controls.Add(this.l_Xlabel);
            this.tabPage1.Controls.Add(this.label25);
            this.tabPage1.Controls.Add(this.l_Xmin);
            this.tabPage1.Controls.Add(this.l_Xmax);
            this.tabPage1.Controls.Add(this.l_Ymin);
            this.tabPage1.Controls.Add(this.l_Ymax);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.tb_CVNScans);
            this.tabPage1.Controls.Add(this.b_Save);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.tb_SWVFreq);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.tb_SWVAmp);
            this.tabPage1.Controls.Add(this.b_SWV);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.tb_SWVStep);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.tb_SWVStop);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.tb_SWVStart);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.tb_CVRate);
            this.tabPage1.Controls.Add(this.b_CV);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.tb_CVSecond);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.tb_CVFirst);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.tb_CVStartStop);
            this.tabPage1.Controls.Add(this.b_CA);
            this.tabPage1.Controls.Add(this.b_Set);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.tb_CATimeStep);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.tb_CATime);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.l_running);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.tb_CAPot);
            this.tabPage1.Controls.Add(this.tb_Pot);
            this.tabPage1.Controls.Add(this.pb_Graph);
            this.tabPage1.Controls.Add(this.l_connection);
            this.tabPage1.Controls.Add(this.l_status);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(914, 613);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Potentiostat";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // l_FREQ
            // 
            this.l_FREQ.AutoSize = true;
            this.l_FREQ.Location = new System.Drawing.Point(241, 548);
            this.l_FREQ.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_FREQ.Name = "l_FREQ";
            this.l_FREQ.Size = new System.Drawing.Size(23, 13);
            this.l_FREQ.TabIndex = 71;
            this.l_FREQ.Text = "-Hz";
            // 
            // l_AMP
            // 
            this.l_AMP.AutoSize = true;
            this.l_AMP.Location = new System.Drawing.Point(241, 522);
            this.l_AMP.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_AMP.Name = "l_AMP";
            this.l_AMP.Size = new System.Drawing.Size(25, 13);
            this.l_AMP.TabIndex = 70;
            this.l_AMP.Text = "-mV";
            // 
            // l_STEP
            // 
            this.l_STEP.AutoSize = true;
            this.l_STEP.Location = new System.Drawing.Point(241, 496);
            this.l_STEP.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_STEP.Name = "l_STEP";
            this.l_STEP.Size = new System.Drawing.Size(25, 13);
            this.l_STEP.TabIndex = 69;
            this.l_STEP.Text = "-mV";
            // 
            // l_SR
            // 
            this.l_SR.AutoSize = true;
            this.l_SR.Location = new System.Drawing.Point(241, 327);
            this.l_SR.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_SR.Name = "l_SR";
            this.l_SR.Size = new System.Drawing.Size(35, 13);
            this.l_SR.TabIndex = 68;
            this.l_SR.Text = "-mV/s";
            // 
            // b_Stop
            // 
            this.b_Stop.Location = new System.Drawing.Point(242, 88);
            this.b_Stop.Name = "b_Stop";
            this.b_Stop.Size = new System.Drawing.Size(51, 23);
            this.b_Stop.TabIndex = 67;
            this.b_Stop.Text = "STOP";
            this.b_Stop.UseVisualStyleBackColor = true;
            this.b_Stop.Click += new System.EventHandler(this.b_Stop_Click);
            // 
            // l_Xlabel
            // 
            this.l_Xlabel.AutoSize = true;
            this.l_Xlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_Xlabel.Location = new System.Drawing.Point(601, 581);
            this.l_Xlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_Xlabel.Name = "l_Xlabel";
            this.l_Xlabel.Size = new System.Drawing.Size(39, 18);
            this.l_Xlabel.TabIndex = 66;
            this.l_Xlabel.Text = "t (s)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(302, 301);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(48, 18);
            this.label25.TabIndex = 65;
            this.label25.Text = "I (uA)";
            // 
            // l_Xmin
            // 
            this.l_Xmin.AutoSize = true;
            this.l_Xmin.Location = new System.Drawing.Point(338, 587);
            this.l_Xmin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_Xmin.Name = "l_Xmin";
            this.l_Xmin.Size = new System.Drawing.Size(10, 13);
            this.l_Xmin.TabIndex = 64;
            this.l_Xmin.Text = "-";
            // 
            // l_Xmax
            // 
            this.l_Xmax.AutoSize = true;
            this.l_Xmax.Location = new System.Drawing.Point(863, 587);
            this.l_Xmax.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_Xmax.Name = "l_Xmax";
            this.l_Xmax.Size = new System.Drawing.Size(10, 13);
            this.l_Xmax.TabIndex = 63;
            this.l_Xmax.Text = "-";
            // 
            // l_Ymin
            // 
            this.l_Ymin.AutoSize = true;
            this.l_Ymin.Location = new System.Drawing.Point(298, 565);
            this.l_Ymin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_Ymin.Name = "l_Ymin";
            this.l_Ymin.Size = new System.Drawing.Size(10, 13);
            this.l_Ymin.TabIndex = 62;
            this.l_Ymin.Text = "-";
            // 
            // l_Ymax
            // 
            this.l_Ymax.AutoSize = true;
            this.l_Ymax.Location = new System.Drawing.Point(298, 62);
            this.l_Ymax.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_Ymax.Name = "l_Ymax";
            this.l_Ymax.Size = new System.Drawing.Size(10, 13);
            this.l_Ymax.TabIndex = 61;
            this.l_Ymax.Text = "-";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(20, 354);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(87, 13);
            this.label24.TabIndex = 60;
            this.label24.Text = "Number of scans";
            // 
            // tb_CVNScans
            // 
            this.tb_CVNScans.Location = new System.Drawing.Point(136, 351);
            this.tb_CVNScans.Name = "tb_CVNScans";
            this.tb_CVNScans.Size = new System.Drawing.Size(100, 20);
            this.tb_CVNScans.TabIndex = 59;
            this.tb_CVNScans.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // b_Save
            // 
            this.b_Save.Location = new System.Drawing.Point(798, 30);
            this.b_Save.Name = "b_Save";
            this.b_Save.Size = new System.Drawing.Size(100, 23);
            this.b_Save.TabIndex = 58;
            this.b_Save.Text = "Save data";
            this.b_Save.UseVisualStyleBackColor = true;
            this.b_Save.Click += new System.EventHandler(this.b_Save_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(20, 548);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 13);
            this.label23.TabIndex = 57;
            this.label23.Text = "Frequency (Hz)";
            // 
            // tb_SWVFreq
            // 
            this.tb_SWVFreq.Location = new System.Drawing.Point(136, 545);
            this.tb_SWVFreq.Name = "tb_SWVFreq";
            this.tb_SWVFreq.Size = new System.Drawing.Size(100, 20);
            this.tb_SWVFreq.TabIndex = 56;
            this.tb_SWVFreq.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(20, 522);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(87, 13);
            this.label18.TabIndex = 55;
            this.label18.Text = "Amplitude (mV/s)";
            // 
            // tb_SWVAmp
            // 
            this.tb_SWVAmp.Location = new System.Drawing.Point(136, 519);
            this.tb_SWVAmp.Name = "tb_SWVAmp";
            this.tb_SWVAmp.Size = new System.Drawing.Size(100, 20);
            this.tb_SWVAmp.TabIndex = 54;
            this.tb_SWVAmp.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // b_SWV
            // 
            this.b_SWV.Location = new System.Drawing.Point(136, 577);
            this.b_SWV.Name = "b_SWV";
            this.b_SWV.Size = new System.Drawing.Size(100, 23);
            this.b_SWV.TabIndex = 53;
            this.b_SWV.Text = "Measure SWV";
            this.b_SWV.UseVisualStyleBackColor = true;
            this.b_SWV.Click += new System.EventHandler(this.button4_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(20, 496);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 13);
            this.label19.TabIndex = 52;
            this.label19.Text = "Step (mV)";
            // 
            // tb_SWVStep
            // 
            this.tb_SWVStep.Location = new System.Drawing.Point(136, 493);
            this.tb_SWVStep.Name = "tb_SWVStep";
            this.tb_SWVStep.Size = new System.Drawing.Size(100, 20);
            this.tb_SWVStep.TabIndex = 51;
            this.tb_SWVStep.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(20, 470);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 13);
            this.label20.TabIndex = 50;
            this.label20.Text = "Stop (mV)";
            // 
            // tb_SWVStop
            // 
            this.tb_SWVStop.Location = new System.Drawing.Point(136, 467);
            this.tb_SWVStop.Name = "tb_SWVStop";
            this.tb_SWVStop.Size = new System.Drawing.Size(100, 20);
            this.tb_SWVStop.TabIndex = 49;
            this.tb_SWVStop.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(20, 444);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 13);
            this.label21.TabIndex = 48;
            this.label21.Text = "Start (mV)";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(20, 421);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(192, 13);
            this.label22.TabIndex = 47;
            this.label22.Text = "Square wave voltammetry (SWV)";
            // 
            // tb_SWVStart
            // 
            this.tb_SWVStart.Location = new System.Drawing.Point(136, 441);
            this.tb_SWVStart.Name = "tb_SWVStart";
            this.tb_SWVStart.Size = new System.Drawing.Size(100, 20);
            this.tb_SWVStart.TabIndex = 46;
            this.tb_SWVStart.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 327);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(87, 13);
            this.label17.TabIndex = 45;
            this.label17.Text = "Scan rate (mV/s)";
            // 
            // tb_CVRate
            // 
            this.tb_CVRate.Location = new System.Drawing.Point(136, 324);
            this.tb_CVRate.Name = "tb_CVRate";
            this.tb_CVRate.Size = new System.Drawing.Size(100, 20);
            this.tb_CVRate.TabIndex = 44;
            this.tb_CVRate.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // b_CV
            // 
            this.b_CV.Location = new System.Drawing.Point(136, 380);
            this.b_CV.Name = "b_CV";
            this.b_CV.Size = new System.Drawing.Size(100, 23);
            this.b_CV.TabIndex = 43;
            this.b_CV.Text = "Measure CV";
            this.b_CV.UseVisualStyleBackColor = true;
            this.b_CV.Click += new System.EventHandler(this.b_CV_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(20, 301);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 13);
            this.label13.TabIndex = 42;
            this.label13.Text = "Second stop (mV)";
            // 
            // tb_CVSecond
            // 
            this.tb_CVSecond.Location = new System.Drawing.Point(136, 298);
            this.tb_CVSecond.Name = "tb_CVSecond";
            this.tb_CVSecond.Size = new System.Drawing.Size(100, 20);
            this.tb_CVSecond.TabIndex = 41;
            this.tb_CVSecond.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(20, 275);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 13);
            this.label14.TabIndex = 40;
            this.label14.Text = "First stop (mV)";
            // 
            // tb_CVFirst
            // 
            this.tb_CVFirst.Location = new System.Drawing.Point(136, 272);
            this.tb_CVFirst.Name = "tb_CVFirst";
            this.tb_CVFirst.Size = new System.Drawing.Size(100, 20);
            this.tb_CVFirst.TabIndex = 39;
            this.tb_CVFirst.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(20, 249);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 13);
            this.label15.TabIndex = 38;
            this.label15.Text = "Start/Stop (mV)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(20, 226);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(140, 13);
            this.label16.TabIndex = 37;
            this.label16.Text = "Cyclic voltammetry (CV)";
            // 
            // tb_CVStartStop
            // 
            this.tb_CVStartStop.Location = new System.Drawing.Point(136, 246);
            this.tb_CVStartStop.Name = "tb_CVStartStop";
            this.tb_CVStartStop.Size = new System.Drawing.Size(100, 20);
            this.tb_CVStartStop.TabIndex = 36;
            this.tb_CVStartStop.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // b_CA
            // 
            this.b_CA.Location = new System.Drawing.Point(136, 191);
            this.b_CA.Name = "b_CA";
            this.b_CA.Size = new System.Drawing.Size(100, 23);
            this.b_CA.TabIndex = 35;
            this.b_CA.Text = "Measure CA";
            this.b_CA.UseVisualStyleBackColor = true;
            this.b_CA.Click += new System.EventHandler(this.b_CA_Click);
            // 
            // b_Set
            // 
            this.b_Set.Location = new System.Drawing.Point(242, 57);
            this.b_Set.Name = "b_Set";
            this.b_Set.Size = new System.Drawing.Size(51, 23);
            this.b_Set.TabIndex = 34;
            this.b_Set.Text = "Set";
            this.b_Set.UseVisualStyleBackColor = true;
            this.b_Set.Click += new System.EventHandler(this.b_Set_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(20, 168);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 13);
            this.label12.TabIndex = 33;
            this.label12.Text = "Time step (ms)";
            // 
            // tb_CATimeStep
            // 
            this.tb_CATimeStep.Location = new System.Drawing.Point(136, 165);
            this.tb_CATimeStep.Name = "tb_CATimeStep";
            this.tb_CATimeStep.Size = new System.Drawing.Size(100, 20);
            this.tb_CATimeStep.TabIndex = 32;
            this.tb_CATimeStep.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 142);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 31;
            this.label11.Text = "Time (s)";
            // 
            // tb_CATime
            // 
            this.tb_CATime.Location = new System.Drawing.Point(136, 139);
            this.tb_CATime.Name = "tb_CATime";
            this.tb_CATime.Size = new System.Drawing.Size(100, 20);
            this.tb_CATime.TabIndex = 30;
            this.tb_CATime.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 116);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 13);
            this.label10.TabIndex = 29;
            this.label10.Text = "Potential (mV)";
            // 
            // l_running
            // 
            this.l_running.AutoSize = true;
            this.l_running.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_running.ForeColor = System.Drawing.Color.Red;
            this.l_running.Location = new System.Drawing.Point(611, 14);
            this.l_running.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_running.Name = "l_running";
            this.l_running.Size = new System.Drawing.Size(183, 37);
            this.l_running.TabIndex = 28;
            this.l_running.Text = "Running ...";
            this.l_running.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(20, 93);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(146, 13);
            this.label9.TabIndex = 27;
            this.label9.Text = "Chronoamperometry (CA)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 62);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 13);
            this.label8.TabIndex = 26;
            this.label8.Text = "Set potential (mV)";
            // 
            // tb_CAPot
            // 
            this.tb_CAPot.Location = new System.Drawing.Point(136, 113);
            this.tb_CAPot.Name = "tb_CAPot";
            this.tb_CAPot.Size = new System.Drawing.Size(100, 20);
            this.tb_CAPot.TabIndex = 25;
            this.tb_CAPot.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // tb_Pot
            // 
            this.tb_Pot.Location = new System.Drawing.Point(136, 59);
            this.tb_Pot.Name = "tb_Pot";
            this.tb_Pot.Size = new System.Drawing.Size(100, 20);
            this.tb_Pot.TabIndex = 24;
            this.tb_Pot.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // l_connection
            // 
            this.l_connection.AutoSize = true;
            this.l_connection.Location = new System.Drawing.Point(798, 14);
            this.l_connection.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_connection.Name = "l_connection";
            this.l_connection.Size = new System.Drawing.Size(111, 13);
            this.l_connection.TabIndex = 20;
            this.l_connection.Text = "Device: disconnected";
            // 
            // l_status
            // 
            this.l_status.AutoSize = true;
            this.l_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_status.Location = new System.Drawing.Point(18, 14);
            this.l_status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_status.Name = "l_status";
            this.l_status.Size = new System.Drawing.Size(198, 25);
            this.l_status.TabIndex = 19;
            this.l_status.Text = "V: --- mV, I: --- uA";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.l_CalibForm);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.tb_ICalibB);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.tb_ICalibA);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.tb_VCalibB);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.tb_VCalibA);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.cb_COMPorts);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(914, 613);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Control";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // l_CalibForm
            // 
            this.l_CalibForm.AutoSize = true;
            this.l_CalibForm.Location = new System.Drawing.Point(33, 143);
            this.l_CalibForm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.l_CalibForm.Name = "l_CalibForm";
            this.l_CalibForm.Size = new System.Drawing.Size(96, 13);
            this.l_CalibForm.TabIndex = 32;
            this.l_CalibForm.Text = "Calibration formula:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(401, 113);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 13);
            this.label5.TabIndex = 31;
            this.label5.Text = "uA";
            // 
            // tb_ICalibB
            // 
            this.tb_ICalibB.Location = new System.Drawing.Point(296, 110);
            this.tb_ICalibB.Name = "tb_ICalibB";
            this.tb_ICalibB.Size = new System.Drawing.Size(100, 20);
            this.tb_ICalibB.TabIndex = 30;
            this.tb_ICalibB.Text = "0";
            this.tb_ICalibB.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(230, 113);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 29;
            this.label6.Text = " uA/dig ; b:";
            // 
            // tb_ICalibA
            // 
            this.tb_ICalibA.Location = new System.Drawing.Point(125, 110);
            this.tb_ICalibA.Name = "tb_ICalibA";
            this.tb_ICalibA.Size = new System.Drawing.Size(100, 20);
            this.tb_ICalibA.TabIndex = 28;
            this.tb_ICalibA.Text = "1";
            this.tb_ICalibA.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 113);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 13);
            this.label7.TabIndex = 27;
            this.label7.Text = "I calibration: a:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(401, 87);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 13);
            this.label4.TabIndex = 26;
            this.label4.Text = "mV";
            // 
            // tb_VCalibB
            // 
            this.tb_VCalibB.Location = new System.Drawing.Point(296, 84);
            this.tb_VCalibB.Name = "tb_VCalibB";
            this.tb_VCalibB.Size = new System.Drawing.Size(100, 20);
            this.tb_VCalibB.TabIndex = 25;
            this.tb_VCalibB.Text = "0";
            this.tb_VCalibB.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(230, 87);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = " mV/dig ; b:";
            // 
            // tb_VCalibA
            // 
            this.tb_VCalibA.Location = new System.Drawing.Point(125, 84);
            this.tb_VCalibA.Name = "tb_VCalibA";
            this.tb_VCalibA.Size = new System.Drawing.Size(100, 20);
            this.tb_VCalibA.TabIndex = 23;
            this.tb_VCalibA.Text = "1";
            this.tb_VCalibA.TextChanged += new System.EventHandler(this.tb_Pot_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 87);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "V calibration: a:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 18);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Select COM port";
            // 
            // cb_COMPorts
            // 
            this.cb_COMPorts.FormattingEnabled = true;
            this.cb_COMPorts.Location = new System.Drawing.Point(28, 43);
            this.cb_COMPorts.Name = "cb_COMPorts";
            this.cb_COMPorts.Size = new System.Drawing.Size(121, 21);
            this.cb_COMPorts.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(980, 34);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(387, 615);
            this.listBox1.TabIndex = 61;
            // 
            // sp_Device
            // 
            this.sp_Device.BaudRate = 57600;
            this.sp_Device.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.sp_Device_DataReceived);
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(33, 196);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(417, 52);
            this.label26.TabIndex = 33;
            this.label26.Text = resources.GetString("label26.Text");
            // 
            // pb_Graph
            // 
            this.pb_Graph.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_Graph.Location = new System.Drawing.Point(353, 59);
            this.pb_Graph.Name = "pb_Graph";
            this.pb_Graph.Size = new System.Drawing.Size(545, 519);
            this.pb_Graph.TabIndex = 21;
            this.pb_Graph.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ControlApp.Properties.Resources.kth;
            this.pictureBox2.Location = new System.Drawing.Point(715, 18);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(176, 160);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 35;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ControlApp.Properties.Resources.inl_logo;
            this.pictureBox1.Location = new System.Drawing.Point(714, 196);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(177, 79);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(941, 663);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(957, 702);
            this.MinimumSize = new System.Drawing.Size(957, 678);
            this.Name = "Form1";
            this.Text = "Potentiostat Control App";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Graph)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tb_SWVAmp;
        private System.Windows.Forms.Button b_SWV;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tb_SWVStep;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tb_SWVStop;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tb_SWVStart;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tb_CVRate;
        private System.Windows.Forms.Button b_CV;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tb_CVSecond;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tb_CVFirst;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tb_CVStartStop;
        private System.Windows.Forms.Button b_CA;
        private System.Windows.Forms.Button b_Set;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tb_CATimeStep;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb_CATime;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label l_running;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_CAPot;
        private System.Windows.Forms.TextBox tb_Pot;
        private System.Windows.Forms.PictureBox pb_Graph;
        private System.Windows.Forms.Label l_connection;
        private System.Windows.Forms.Label l_status;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_ICalibB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_ICalibA;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_VCalibB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_VCalibA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_COMPorts;
        private System.Windows.Forms.Button b_Save;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tb_SWVFreq;
        private System.IO.Ports.SerialPort sp_Device;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label l_CalibForm;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tb_CVNScans;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label l_Xlabel;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label l_Xmin;
        private System.Windows.Forms.Label l_Xmax;
        private System.Windows.Forms.Label l_Ymin;
        private System.Windows.Forms.Label l_Ymax;
        private System.Windows.Forms.Button b_Stop;
        private System.Windows.Forms.Label l_SR;
        private System.Windows.Forms.Label l_FREQ;
        private System.Windows.Forms.Label l_AMP;
        private System.Windows.Forms.Label l_STEP;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label26;
    }
}

