﻿//This is a user interface and control app for Mini Potentiostat
//Hamedi Lab Royal Institute of Technology (KTH), Stockholm, Sweden & International Iberian Nanotechnology Lab (INL), Braga, Portugal.
//Developed by Alar Ainla, 2021
//--------------------------------------------------------------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ControlApp
{
    public partial class Form1 : Form
    {
        bool isRunning = false;
        int Potential=2048; //Digital word
        //Calibration constants
        double Va, Vb, Ia, Ib; //For voltage and current
        int mType = 0; //Measurement type 1- CA, 2-CV, 3-SWV, 0 - nothing
        //Data storage
        double[] I; //Current (uA)
        double[] V; //Potential (mV)
        double[] t; //Time (s)

        int[] Nstep; //Step number
        int cnt;    //Counter
        //CV variables
        int[] stepR; //Step height
        int[] nrSteps; //Number of steps
        int nrScans; //Number of individual scans
        int ScanNr; //Current scan number

        List<string> commands; //Commands list

        Bitmap img;

        public Form1()
        {
            InitializeComponent();
        }

        //Measure square wave
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                double tmp_start = Convert.ToDouble(tb_SWVStart.Text);  //Start (mV)
                double tmp_stop = Convert.ToDouble(tb_SWVStop.Text);    //Stop (mV)
                double tmp_step = Convert.ToDouble(tb_SWVStep.Text);    //Step (mV)
                double tmp_amp = Convert.ToDouble(tb_SWVAmp.Text);      //Amp (mV)
                double tmp_freq = Convert.ToDouble(tb_SWVFreq.Text);    //Freq (Hz)
                //Check if parameters are fine
                if (tmp_freq > 100)
                {
                    MessageBox.Show("Frequency cannot be more than 100");
                    return;
                }
                if (tmp_step < (-1) * Va)
                {
                    MessageBox.Show("Too small step");
                    return;
                }
                if (tmp_amp < (-1) * Va)
                {
                    MessageBox.Show("Too small amplitude");
                    return;
                }
                if (tmp_start == tmp_stop)
                {
                    MessageBox.Show("Start and stop cannot be same");
                    return;
                }
                //If all parameters fine compute
                int tmp_step_D = Convert.ToInt32(tmp_step / ((-1) * Va));
                int tmp_amp_D = Convert.ToInt32(tmp_amp / ((-1) * Va));
                int tmp_interval = Convert.ToInt32(500000 / tmp_freq);
                double tmp_act_step = (Convert.ToDouble(tmp_step_D) * ((-1) * Va));
                double tmp_act_amp = (Convert.ToDouble(tmp_amp_D) * ((-1) * Va));
                double tmp_act_freq = (500000 / Convert.ToDouble(tmp_interval));
                //Show actual parameters used
                l_STEP.Text = tmp_act_step.ToString("F2") + " mV";
                l_AMP.Text = tmp_act_amp.ToString("F2") + " mV";
                l_FREQ.Text = tmp_act_freq.ToString("F2") + " Hz";

                int tmp_N = 2 * Convert.ToInt32((tmp_start - tmp_stop) / tmp_act_step);
                if (tmp_N < 0)
                { 
                    tmp_N = (-1) * tmp_N;
                    tmp_step_D = (-1) * tmp_step_D;
                }
                else
                {

                }
                initArrays(tmp_N + 2);
                //Make control sequence for the measurement
                Potential = convertPotmV2D(tmp_start);
                commands.Add("F" + tmp_N.ToString());
                commands.Add("C" + tmp_interval.ToString());
                commands.Add("D" + (tmp_step_D+2*tmp_amp_D).ToString());
                commands.Add("E" + ((-2) * tmp_amp_D).ToString());
                commands.Add("A" + Potential.ToString());
                commands.Add("G0");
                cnt = 0;
                mType = 3; //SWV
                isRunning = true; //Run
                l_running.Visible = true;
                
            }
            catch (Exception e1)
            {
                MessageBox.Show("Some input parameters are not correct numbers!");
            }
        }

        //When text box value is changed save it
        private void tb_Pot_TextChanged(object sender, EventArgs e)
        {
            string[] settings = new string[18];
            settings[0] = tb_CAPot.Text;
            settings[1] = tb_CATime.Text;
            settings[2] = tb_CATimeStep.Text;
            settings[3] = tb_CVFirst.Text;
            settings[4] = tb_CVRate.Text;
            settings[5] = tb_CVSecond.Text;
            settings[6] = tb_CVStartStop.Text;
            settings[7] = tb_ICalibA.Text;
            settings[8] = tb_ICalibB.Text;
            settings[9] = tb_Pot.Text;
            settings[10] = tb_SWVAmp.Text;
            settings[11] = tb_SWVFreq.Text;
            settings[12] = tb_SWVStart.Text;
            settings[13] = tb_SWVStep.Text;
            settings[14] = tb_SWVStop.Text;
            settings[15] = tb_VCalibA.Text;
            settings[16] = tb_VCalibB.Text;
            settings[17] = tb_CVNScans.Text;
            File.WriteAllLines("SETTINGS.txt", settings);
            //Try to convert
            try
            {
                Va = Convert.ToDouble(tb_VCalibA.Text);
                Vb = Convert.ToDouble(tb_VCalibB.Text);
                Ia = Convert.ToDouble(tb_ICalibA.Text);
                Ib = Convert.ToDouble(tb_ICalibB.Text);
                l_CalibForm.Text = "Calibration: V=" + Va.ToString() + "mV/dig + " + Vb.ToString() + "mV AND I=" + Ia.ToString() + "uA/dig + " + Ib.ToString() + "uA";
                if((Va==0)||(Ia==0)) l_CalibForm.Text = "Error: slopes cannot be zero!";
            }
            catch(Exception e1)
            {
                l_CalibForm.Text = "Calibration constants have errors!";
            }
        }

        //Load settings
        private void Form1_Load(object sender, EventArgs e)
        {
            isRunning = false;
            commands = new List<string>();

            timer1.Start();
            cb_COMPorts.Items.Add("AUTO");
            for (int i = 0; i < 256; i++) cb_COMPorts.Items.Add("COM" + Convert.ToString(i + 1));
            try
            {
                string[] COMtxt = File.ReadAllLines("COM.txt");
                cb_COMPorts.Text = COMtxt[0];
            }
            catch (Exception e1)
            {
                string[] COMtxt = new string[1];
                COMtxt[0] = "AUTO";
                File.WriteAllLines("COM.txt", COMtxt);
                cb_COMPorts.Text = "AUTO";
            }
            try
            {
                string[] settings = File.ReadAllLines("SETTINGS.txt");
                tb_CAPot.Text = settings[0];
                tb_CATime.Text = settings[1];
                tb_CATimeStep.Text = settings[2];
                tb_CVFirst.Text = settings[3];
                tb_CVRate.Text = settings[4];
                tb_CVSecond.Text = settings[5];
                tb_CVStartStop.Text = settings[6];
                tb_ICalibA.Text = settings[7];
                tb_ICalibB.Text = settings[8];
                tb_Pot.Text = settings[9];
                tb_SWVAmp.Text = settings[10];
                tb_SWVFreq.Text = settings[11];
                tb_SWVStart.Text = settings[12];
                tb_SWVStep.Text = settings[13];
                tb_SWVStop.Text = settings[14];
                tb_VCalibA.Text = settings[15];
                tb_VCalibB.Text = settings[16];
                tb_CVNScans.Text = settings[17];
            }
            catch (Exception e1)
            {

            }
        }

        // When data is received
        private void sp_Device_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                setText(l_status, sp_Device.ReadLine());
            }
            catch (Exception e1)
            {

            }
        }

        //Process incoming data
        public void setText(Control mycont, string text)
        {
            if (this.InvokeRequired)
            {
                try
                {
                    this.BeginInvoke(new Action<Control, string>(setText), new object[] { mycont, text });
                }
                catch (Exception ex)
                {
                    return; //Do nothing
                }
            }
            else
            {
                if (text.Substring(0, 1) == "i") //Current request
                {
                    string currText = text.Substring(6);
                    l_status.Text = "V: " + convertPotD2mV(Potential).ToString("F1") + "mV , I: " + convertID2uA(Convert.ToInt32(currText)) + "uA";

                }
                if (text.Substring(0, 1) == ">") //Data stream
                {
                    //listBox1.Items.Add(text);
                    if (cnt < t.Length)
                    {
                        int i;
                        string text2 = text.Substring(1);
                        i = text2.IndexOf(',');
                        string text3 = text2.Substring(0, i);
                        Nstep[cnt] = Convert.ToInt32(text3);
                        //Time
                        text2 = text2.Substring(i + 1);
                        i = text2.IndexOf(',');
                        text3 = text2.Substring(0, i);
                        t[cnt] = Convert.ToInt32(text3) / 1000000.0;
                        //Potential
                        text2 = text2.Substring(i + 1);
                        i = text2.IndexOf(',');
                        text3 = text2.Substring(0, i);
                        V[cnt] = convertPotD2mV(Convert.ToInt32(text3));
                        Potential = convertPotmV2D(V[cnt]);
                        //Current
                        text2 = text2.Substring(i + 1);
                        I[cnt] = convertID2uA(Convert.ToInt32(text2));
                        l_status.Text = "V: " + V[cnt].ToString("F1") + "mV , I: " + convertID2uA(Convert.ToInt32(I[cnt])) + "uA";
                        cnt++;
                        
                        makeGraph();
                    }
                    else
                    {
                        l_status.Text = "Something wrong!";
                        listBox1.Items.Add(text);
                    }


                }
                if (text.Substring(0, 1) == "g") //Done the run
                {
                    if(mType==2) //If CV send next scan parameters
                    {
                        ScanNr++;
                        if(ScanNr==nrScans) //Done
                        {
                            l_running.Visible = false;
                            isRunning = false;
                         //   makeGraph();
                        }
                        else
                        {
                            commands.Add("F" + nrSteps[ScanNr].ToString());
                            commands.Add("D" + stepR[ScanNr].ToString());
                            commands.Add("E" + stepR[ScanNr].ToString());
                            commands.Add("G0");
                        }
                    }
                    else
                    {
                        l_running.Visible = false;
                        isRunning = false;
                       // makeGraph();
                    }
                }
            }
        }

        //Make graph
        private void makeGraph()
        {
            switch(mType)
            {
                case 1: makeGraph_CA(); return;
                case 2: makeGraph_CV(); return;
                case 3: makeGraph_SWV(); return;
                default:
                    makeGraph_CA();
                    return;
            }
        }

        //Make graphs CA
        private void makeGraph_CA()
        {
            if (cnt < 2) return;
            img = new Bitmap(pb_Graph.Width, pb_Graph.Height);
            Graphics gr = Graphics.FromImage(img);
            Pen mypen;
            mypen = new Pen(Color.Red, 1);
            double verta;
            double vertb;
            double hora;

            // ---- V1 ----
            double Y_min = 1e20;
            double Y_max = -1e20;
            for (int i = 0; i < cnt; i++)
            {
                if (I[i] > Y_max) Y_max = I[i];
                if (I[i] < Y_min) Y_min = I[i];
            }
            Y_max = Y_max + 0.1;
            Y_min = Y_min - 0.1;
            double X_min, X_max;
            X_min = t[0];
            X_max = t[cnt - 1];
            l_Xmax.Text = X_max.ToString("F1");
            l_Xmin.Text = X_min.ToString("F1");
            l_Ymax.Text = Y_max.ToString("F3");
            l_Ymin.Text = Y_min.ToString("F3");
            l_Xlabel.Text = "t (s)";


            verta = (((double)pb_Graph.Height) / (Y_max - Y_min));
            vertb = (-1) * (Y_min * verta);
            hora = ((double)pb_Graph.Width) / cnt;

            for (int i = 1; i < cnt; i++)
            {
                int x1 = (int)(hora * (i - 1));
                int x2 = (int)(hora * i);
                int y1 = (int)(((float)pb_Graph.Height) - (verta * I[i - 1] + vertb));
                int y2 = (int)(((float)pb_Graph.Height) - (verta * I[i] + vertb));
                gr.DrawLine(mypen, x1, y1, x2, y2);
            }

            pb_Graph.Image = img;
            pb_Graph.Update();
            GC.Collect();
        }

        //Make graph CV
        private void makeGraph_CV()
        {
            if (cnt < 2) return;
            img = new Bitmap(pb_Graph.Width, pb_Graph.Height);
            Graphics gr = Graphics.FromImage(img);
            Pen mypen;
            mypen = new Pen(Color.Red, 1);
            double verta;
            double vertb;
            double hora;
            double horb;

            // ---- V1 ----
            double Y_min = 1e20;
            double Y_max = -1e20;
            for (int i = 0; i < cnt; i++)
            {
                if (I[i] > Y_max) Y_max = I[i];
                if (I[i] < Y_min) Y_min = I[i];
            }
            Y_max = Y_max + 0.1;
            Y_min = Y_min - 0.1;

            double X_min = 1e20;
            double X_max = -1e20;
            for (int i = 0; i < cnt; i++)
            {
                if (V[i] > X_max) X_max = V[i];
                if (V[i] < X_min) X_min = V[i];
            }
            X_max = X_max + 0.1;
            X_min = X_min - 0.1;

            l_Xmax.Text = X_max.ToString("F1");
            l_Xmin.Text = X_min.ToString("F1");
            l_Ymax.Text = Y_max.ToString("F3");
            l_Ymin.Text = Y_min.ToString("F3");
            l_Xlabel.Text = "V (mV)";

            verta = (((double)pb_Graph.Height) / (Y_max - Y_min));
            vertb = (-1) * (Y_min * verta);
            hora = (((double)pb_Graph.Width) / (X_max - X_min));
            horb = (-1) * (X_min * hora);

            for (int i = 1; i < cnt; i++)
            {
                int x1 = (int)((hora * V[i - 1] + horb));
                int x2 = (int)((hora * V[i] + horb));
                int y1 = (int)(((float)pb_Graph.Height) - (verta * I[i - 1] + vertb));
                int y2 = (int)(((float)pb_Graph.Height) - (verta * I[i] + vertb));
                gr.DrawLine(mypen, x1, y1, x2, y2);
            }

            pb_Graph.Image = img;
            pb_Graph.Update();
            GC.Collect();
        }

        //Naje SWV graph
        private void makeGraph_SWV()
        {
            if (cnt < 4) return;
            if ((cnt % 2) == 1) return;

            img = new Bitmap(pb_Graph.Width, pb_Graph.Height);
            Graphics gr = Graphics.FromImage(img);
            Pen mypen;
            mypen = new Pen(Color.Red, 1);
            double verta;
            double vertb;
            double hora;
            double horb;

            // ---- V1 ----
            double Y_min = 1e20;
            double Y_max = -1e20;
            for (int i = 0; i < cnt/2; i++)
            {
                double Id = I[i * 2 + 1] - I[i * 2];
                if (Id > Y_max) Y_max = Id;
                if (Id < Y_min) Y_min = Id;
            }
            Y_max = Y_max + 0.1;
            Y_min = Y_min - 0.1;

            double X_min = 1e20;
            double X_max = -1e20;
            for (int i = 0; i < cnt; i++)
            {
                if (V[i] > X_max) X_max = V[i];
                if (V[i] < X_min) X_min = V[i];
            }
            X_max = X_max + 0.1;
            X_min = X_min - 0.1;

            l_Xmax.Text = X_max.ToString("F1");
            l_Xmin.Text = X_min.ToString("F1");
            l_Ymax.Text = Y_max.ToString("F3");
            l_Ymin.Text = Y_min.ToString("F3");
            l_Xlabel.Text = "V (mV)";

            verta = (((double)pb_Graph.Height) / (Y_max - Y_min));
            vertb = (-1) * (Y_min * verta);
            hora = (((double)pb_Graph.Width) / (X_max - X_min));
            horb = (-1) * (X_min * hora);

            for (int i = 1; i < cnt/2; i++)
            {
                double V1 = (V[(i - 1) * 2] + V[(i - 1) * 2 + 1]) / 2;
                double V2= (V[(i) * 2] + V[(i) * 2 + 1]) / 2;
                double dI1= (I[(i - 1) * 2+1] - I[(i - 1) * 2]);
                double dI2 = (I[(i) * 2+1] - I[(i) * 2]);

                int x1 = (int)((hora * V1 + horb));
                int x2 = (int)((hora * V2 + horb));
                int y1 = (int)(((float)pb_Graph.Height) - (verta * dI1 + vertb));
                int y2 = (int)(((float)pb_Graph.Height) - (verta * dI2 + vertb));
                gr.DrawLine(mypen, x1, y1, x2, y2);
            }

            pb_Graph.Image = img;
            pb_Graph.Update();
            GC.Collect();
        }

        //When timer ticks
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!sp_Device.IsOpen)
            {
                l_connection.Text = "Device: disconnected";
                if (cb_COMPorts.Text == "AUTO")
                {
                    for (int i = 0; i < 256; i++)
                        try
                        {
                            sp_Device.PortName = "COM" + Convert.ToString(i + 1);
                            sp_Device.Open();
                            //timeBeg = ((double)DateTime.Now.Ticks / (double)TimeSpan.TicksPerMillisecond) / 1000;
                            return;
                        }
                        catch (Exception ex) { }
                }
                else
                {
                    try
                    {
                        sp_Device.PortName = cb_COMPorts.Text;
                        sp_Device.Open();
                        //timeBeg = ((double)DateTime.Now.Ticks / (double)TimeSpan.TicksPerMillisecond) / 1000;
                        return;
                    }
                    catch (Exception ex) { }
                }
            }
            else
            {
                l_connection.Text = "Device: connected";
                //If device is connected then request current measurement
                if(!isRunning)
                    sp_Device.WriteLine("I0");
                if(commands.Count>0)
                {
                    sp_Device.WriteLine(commands.ElementAt(0));
                    listBox1.Items.Add(commands.ElementAt(0));
                    commands.RemoveAt(0);
                }
            }

        }

        //Set potential
        private void b_Set_Click(object sender, EventArgs e)
        {
            try
            {
                double tmp = Convert.ToInt32(tb_Pot.Text);
                if (tmp < -2000) tmp = -2000;
                if (tmp > 2000) tmp = 2000;
                Potential = convertPotmV2D(tmp);
                sp_Device.WriteLine("A" + Potential.ToString());
            }
            catch(Exception e1)
            {
                MessageBox.Show("Error, potential is not a number!");
            }
        }

        //Start CA
        private void b_CA_Click(object sender, EventArgs e)
        {
            try
            {
                double tmp_pot = Convert.ToDouble(tb_CAPot.Text);
                double tmp_timestep = Convert.ToDouble(tb_CATimeStep.Text);
                double tmp_time = Convert.ToDouble(tb_CATime.Text);
                if (tmp_timestep < 2.5)
                {
                    MessageBox.Show("Timestep has to be over 2.5ms");
                    return;
                }
                if (tmp_time * 1000 / tmp_timestep > 10000) tmp_time = tmp_timestep * 10;
                int tmp_ts = Convert.ToInt32(tmp_timestep * 1000);
                int tmp_N = Convert.ToInt32(tmp_time * 1000 / (((double)tmp_ts)/1000.0));
                Potential = convertPotmV2D(tmp_pot);
                initArrays(tmp_N+2);
                commands.Add("F" + tmp_N.ToString());
                commands.Add("C" + tmp_ts.ToString());
                commands.Add("D0");
                commands.Add("E0");
                commands.Add("A" + Potential.ToString());
                commands.Add("G0");
                isRunning = true;
                mType = 1;
                l_running.Visible = true;
            }
            catch(Exception e1)
            {
                MessageBox.Show("Some input parameters are not correct numbers!");
            }
        }

        //Convert potential from digits to mV
        double convertPotD2mV(int potin)
        {
            return potin * Va + Vb;
        }

        //Start CV recording
        private void b_CV_Click(object sender, EventArgs e)
        {
            try
            {
                double tmp_pot_ss = Convert.ToDouble(tb_CVStartStop.Text); //Start/Stop
                double tmp_stop1 = Convert.ToDouble(tb_CVFirst.Text); //Stop 1
                double tmp_stop2 = Convert.ToDouble(tb_CVSecond.Text); //Stop 2
                double tmp_sr = Convert.ToDouble(tb_CVRate.Text); //Scan rate
                double tmp_ts = Convert.ToDouble(tb_CATimeStep.Text); //Time step
                int tmp_NRS = Convert.ToInt32(tb_CVNScans.Text); //Number of full cycles

                if (tmp_NRS<1)
                {
                    MessageBox.Show("Number of scan must be larger than 0");
                    return;
                }
                if (tmp_ts < 2.5)
                {
                    MessageBox.Show("Timestep has to be over 2.5ms");
                    return;
                }
                if (!(((tmp_pot_ss<tmp_stop1)&&(tmp_pot_ss>tmp_stop2))|| ((tmp_pot_ss < tmp_stop2) && (tmp_pot_ss > tmp_stop1)))) //Starting has to be between first and second
                {
                    MessageBox.Show("Start/Stop potential should be between the first and second stop!");
                    return;
                }
                //If all parameters fine compute
               // double upperV, lowerV;
                int nrSteps1, nrSteps2, nrSteps3;
                int tmp_stepH = Convert.ToInt32(tmp_ts * tmp_sr / (1000.0 * Va)); //Find step height
                double tmp_act_sr = tmp_stepH * Va / (tmp_ts / 1000); //Actual scan rate
                if (tmp_stop1>tmp_stop2)
                {
                    //upperV = tmp_stop1; lowerV = tmp_stop2;
                    nrSteps1 = Convert.ToInt32((tmp_stop1 - tmp_pot_ss) / ((tmp_ts / 1000) * tmp_act_sr));
                    nrSteps2 = Convert.ToInt32((tmp_stop1 - tmp_stop2) / ((tmp_ts / 1000) * tmp_act_sr));
                    nrSteps3 = Convert.ToInt32((tmp_pot_ss - tmp_stop2) / ((tmp_ts / 1000) * tmp_act_sr));
                    tmp_stepH = (-1) * tmp_stepH; //Flip initial direction                  
                }
                else
                {
                    //upperV = tmp_stop2; lowerV = tmp_stop1; 
                    nrSteps1 = Convert.ToInt32((tmp_pot_ss- tmp_stop1) / ((tmp_ts / 1000) * tmp_act_sr));
                    nrSteps2 = Convert.ToInt32((tmp_stop2 - tmp_stop1) / ((tmp_ts / 1000) * tmp_act_sr));
                    nrSteps3 = Convert.ToInt32((tmp_stop2-tmp_pot_ss) / ((tmp_ts / 1000) * tmp_act_sr));
                }
                l_SR.Text = tmp_act_sr.ToString("F2") + " mV/s"; // Actual scan rate

                nrScans = 2 * tmp_NRS + 1;
                stepR = new int[nrScans];
                nrSteps = new int[nrScans];
                int tmp_N=nrSteps1+nrSteps3+ nrSteps2*(tmp_NRS*2-1);
                for(int i=0; i<tmp_NRS; i++)
                {
                    stepR[i * 2 + 1] = tmp_stepH;
                    stepR[i * 2 + 2] = (-1)*tmp_stepH;
                    nrSteps[i * 2 + 1] = nrSteps2;
                    nrSteps[i * 2 + 2] = nrSteps2;
                }
                stepR[0] = (-1) * tmp_stepH;
                nrSteps[0] = nrSteps1;
                nrSteps[nrScans - 1] = nrSteps3;
                int tmp_ts2 = Convert.ToInt32(tmp_ts * 1000);
                initArrays(tmp_N+tmp_NRS*10);
                Potential = convertPotmV2D(tmp_pot_ss);
                commands.Add("F" + nrSteps[0].ToString());
                commands.Add("C" + tmp_ts2.ToString());
                commands.Add("D"+ stepR[0].ToString());
                commands.Add("E"+ stepR[0].ToString());
                commands.Add("A" + Potential.ToString());
                commands.Add("G0");
                cnt = 0;
                mType = 2; //CV
                ScanNr = 0; //Current scan
                isRunning = true; //Run
                l_running.Visible = true;
            }
            catch(Exception e1)
            {
                MessageBox.Show("Some input parameters are not correct numbers!");
            }
        }

        //Stop measurement
        private void b_Stop_Click(object sender, EventArgs e)
        {
            isRunning = false;
            l_running.Visible = false;
            sp_Device.WriteLine("H0");
            //commands.Add("H0");
        }

        //Save data
        private void b_Save_Click(object sender, EventArgs e)
        {
            //If there is any data
            if (cnt == 0)
            {
                MessageBox.Show("No data to save");
                return;
            }
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string fileName = sfd.FileName;
                    //Process files
                    int fcnt = 1;
                    StreamWriter fout = new StreamWriter(fileName);
                    if (mType == 1)
                    {
                        fout.WriteLine("CA data");
                        fout.WriteLine("Time (s); Potential (mV); Current (uA)");
                        for (int i = 0; i < cnt; i++)
                        {
                            string tmp = t[i].ToString("F4") + "; " + V[i].ToString("F1") + "; " + I[i].ToString("F4");
                            fout.WriteLine(tmp);
                        }
                        fout.Close();
                    }
                    if (mType == 2)
                    {
                        fout.WriteLine("CV data");
                        fout.WriteLine("Time (s); Potential (mV); Current (uA)");
                        for (int i = 0; i < cnt; i++)
                        {
                            string tmp = t[i].ToString("F4") + "; " + V[i].ToString("F1") + "; " + I[i].ToString("F4");
                            fout.WriteLine(tmp);
                        }
                        fout.Close();
                    }
                    if (mType == 3)
                    {
                        fout.WriteLine("SWV data");
                        fout.WriteLine("Potential (mV); SWVCurrent (uA); Time.1 (s); Potential.1 (mV); Current.1 (uA); Time.2 (s); Potential.2 (mV); Current.2 (uA)");
                        for (int i = 0; i < cnt / 2; i++)
                        {
                            string tmp = ((V[i * 2] + V[i * 2 + 1]) / 2).ToString("F1") + "; " + ((I[i * 2 + 1] - I[i * 2])).ToString("F4") + "; " + t[i * 2].ToString("F4") + "; " + V[i * 2].ToString("F1") + "; " + I[i * 2].ToString("F4") + "; " + t[i * 2 + 1].ToString("F4") + "; " + V[i * 2 + 1].ToString("F1") + "; " + I[i * 2 + 1].ToString("F4");
                            fout.WriteLine(tmp);
                        }
                        fout.Close();
                    }
                }
                catch (Exception ex) { }
            }
        }
        //Convert potential from mV to digits
        int convertPotmV2D(double potin)
        {
            return Convert.ToInt32((potin-Vb)/Va);
        }
        //Convert current from digits to mV
        double convertID2uA(int currin)
        {
            return ((double)currin) * Ia + Ib;
        }
        //Initialize arrays
        void initArrays(int n)
        {
            V = new double[n];
            I = new double[n];
            t = new double[n];
            Nstep = new int[n];
            cnt = 0;
        }

    }
}
